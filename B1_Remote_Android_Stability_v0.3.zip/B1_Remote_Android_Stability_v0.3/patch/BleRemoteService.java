package com.fks.b1remote;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattServer;
import android.bluetooth.BluetoothGattServerCallback;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.AdvertiseCallback;
import android.bluetooth.le.AdvertiseData;
import android.bluetooth.le.AdvertiseSettings;
import android.bluetooth.le.BluetoothLeAdvertiser;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.ParcelUuid;
import android.util.Log;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

public class BleRemoteService extends Service {
    public static final String SERVICE_UUID_STRING = "7b3e1001-2f9a-4e2a-9a6b-1c6c0f9b1001";
    public static final String COMMAND_UUID_STRING = "7b3e1002-2f9a-4e2a-9a6b-1c6c0f9b1001";

    private static final String TAG = "B1RemoteBLE";
    private static final String CHANNEL = "b1_remote_ble";
    private static final int NOTIFICATION_ID = 1202;
    private static volatile String status = "STOPPED";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private BluetoothManager bluetoothManager;
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothGattServer gattServer;
    private BluetoothLeAdvertiser advertiser;
    private BluetoothGattCharacteristic commandCharacteristic;

    private boolean gattReady = false;
    private boolean advertisingActive = false;
    private int connectedClients = 0;
    private int recoveryGeneration = 0;

    public static String getPublicStatus() { return status; }

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(NOTIFICATION_ID, notification("Starting Bluetooth receiver…"));
        registerReceiver(adapterReceiver, new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED));
        startBleStack("service-create");
        handler.postDelayed(watchdog, 7000);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        ensureHealthy("start-command");
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        recoveryGeneration++;
        handler.removeCallbacksAndMessages(null);
        try { unregisterReceiver(adapterReceiver); } catch (Throwable ignored) {}
        stopBleStack();
        setStatus("STOPPED");
        super.onDestroy();
    }

    private synchronized void startBleStack(String reason) {
        recoveryGeneration++;
        int generation = recoveryGeneration;
        Log.i(TAG, "startBleStack reason=" + reason + " generation=" + generation);

        stopBleStack();
        bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        if (bluetoothManager == null) { setStatus("NO_BLUETOOTH_MANAGER"); return; }

        bluetoothAdapter = bluetoothManager.getAdapter();
        if (bluetoothAdapter == null) { setStatus("NO_BLUETOOTH_ADAPTER"); return; }
        if (!bluetoothAdapter.isEnabled()) { setStatus("BLUETOOTH_OFF"); return; }

        advertiser = bluetoothAdapter.getBluetoothLeAdvertiser();
        if (advertiser == null) { setStatus("ADVERTISING_UNSUPPORTED"); return; }

        gattServer = bluetoothManager.openGattServer(this, gattCallback);
        if (gattServer == null) { setStatus("GATT_SERVER_FAILED"); scheduleFullRecovery("gatt-open", 1200); return; }

        BluetoothGattService service = new BluetoothGattService(
                UUID.fromString(SERVICE_UUID_STRING),
                BluetoothGattService.SERVICE_TYPE_PRIMARY
        );

        commandCharacteristic = new BluetoothGattCharacteristic(
                UUID.fromString(COMMAND_UUID_STRING),
                BluetoothGattCharacteristic.PROPERTY_WRITE
                        | BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE
                        | BluetoothGattCharacteristic.PROPERTY_READ,
                BluetoothGattCharacteristic.PERMISSION_WRITE
                        | BluetoothGattCharacteristic.PERMISSION_READ
        );
        commandCharacteristic.setValue("READY");
        service.addCharacteristic(commandCharacteristic);

        boolean requested = gattServer.addService(service);
        Log.i(TAG, "GATT service add requested=" + requested);
        if (requested) setStatus("GATT_STARTING");
        else {
            setStatus("GATT_ADD_FAILED");
            scheduleFullRecovery("gatt-add", 1200);
        }
    }

    private synchronized void ensureHealthy(String reason) {
        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled()) {
            startBleStack(reason + "-adapter");
            return;
        }
        if (gattServer == null || !gattReady) {
            startBleStack(reason + "-gatt");
            return;
        }
        if (connectedClients == 0 && !advertisingActive) {
            restartAdvertising(reason + "-advertising");
        }
    }

    private synchronized void restartAdvertising(String reason) {
        if (advertiser == null || !gattReady) {
            scheduleFullRecovery(reason + "-missing-stack", 500);
            return;
        }
        Log.i(TAG, "restartAdvertising reason=" + reason);
        try { advertiser.stopAdvertising(advertiseCallback); } catch (Throwable ignored) {}
        advertisingActive = false;
        handler.postDelayed(() -> startAdvertising(reason), 180);
    }

    private synchronized void startAdvertising(String reason) {
        if (advertiser == null || !gattReady || bluetoothAdapter == null || !bluetoothAdapter.isEnabled()) return;

        AdvertiseSettings settings = new AdvertiseSettings.Builder()
                .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
                .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM)
                .setConnectable(true)
                .setTimeout(0)
                .build();

        AdvertiseData data = new AdvertiseData.Builder()
                .setIncludeDeviceName(false)
                .addServiceUuid(new ParcelUuid(UUID.fromString(SERVICE_UUID_STRING)))
                .build();

        Log.i(TAG, "startAdvertising reason=" + reason);
        advertisingActive = false;
        setStatus("ADVERTISING_STARTING");
        try {
            advertiser.startAdvertising(settings, data, advertiseCallback);
        } catch (Throwable t) {
            Log.e(TAG, "startAdvertising exception", t);
            setStatus("ADVERTISE_EXCEPTION");
            scheduleFullRecovery("advertise-exception", 1200);
        }
    }

    private synchronized void scheduleFullRecovery(String reason, long delayMs) {
        final int generation = ++recoveryGeneration;
        Log.w(TAG, "scheduleFullRecovery reason=" + reason + " delay=" + delayMs + " generation=" + generation);
        handler.postDelayed(() -> {
            if (generation != recoveryGeneration) return;
            startBleStack("recovery:" + reason);
        }, delayMs);
    }

    private synchronized void stopBleStack() {
        advertisingActive = false;
        gattReady = false;
        connectedClients = 0;
        try { if (advertiser != null) advertiser.stopAdvertising(advertiseCallback); } catch (Throwable ignored) {}
        try {
            if (gattServer != null) {
                gattServer.clearServices();
                gattServer.close();
            }
        } catch (Throwable ignored) {}
        advertiser = null;
        gattServer = null;
        commandCharacteristic = null;
    }

    private final BluetoothGattServerCallback gattCallback = new BluetoothGattServerCallback() {
        @Override
        public void onServiceAdded(int statusCode, BluetoothGattService service) {
            Log.i(TAG, "onServiceAdded status=" + statusCode + " uuid=" + (service != null ? service.getUuid() : "null"));
            if (statusCode == BluetoothGatt.GATT_SUCCESS) {
                gattReady = true;
                startAdvertising("service-added");
            } else {
                gattReady = false;
                setStatus("GATT_SERVICE_ERROR_" + statusCode);
                scheduleFullRecovery("service-add-" + statusCode, 1200);
            }
        }

        @Override
        public void onConnectionStateChange(BluetoothDevice device, int statusCode, int newState) {
            String address = device != null ? device.getAddress() : "null";
            Log.i(TAG, "Connection device=" + address + " status=" + statusCode + " state=" + newState);

            if (newState == BluetoothGatt.STATE_CONNECTED && statusCode == BluetoothGatt.GATT_SUCCESS) {
                connectedClients = 1;
                setStatus("CONNECTED");
                return;
            }

            if (newState == BluetoothGatt.STATE_DISCONNECTED) {
                connectedClients = 0;
                advertisingActive = false;
                setStatus("DISCONNECTED_RECOVERING");
                // Amlogic/Android 9 can stop connectable advertising after a GATT
                // session. Force a fresh advertising cycle after every disconnect.
                handler.postDelayed(() -> restartAdvertising("client-disconnect"), 250);
            }

            if (statusCode != BluetoothGatt.GATT_SUCCESS) {
                scheduleFullRecovery("gatt-status-" + statusCode, 1000);
            }
        }

        @Override
        public void onCharacteristicReadRequest(
                BluetoothDevice device,
                int requestId,
                int offset,
                BluetoothGattCharacteristic characteristic
        ) {
            if (gattServer != null) {
                gattServer.sendResponse(
                        device,
                        requestId,
                        BluetoothGatt.GATT_SUCCESS,
                        offset,
                        "READY".getBytes(StandardCharsets.UTF_8)
                );
            }
        }

        @Override
        public void onCharacteristicWriteRequest(
                BluetoothDevice device,
                int requestId,
                BluetoothGattCharacteristic characteristic,
                boolean preparedWrite,
                boolean responseNeeded,
                int offset,
                byte[] value
        ) {
            String command = value == null ? "" : new String(value, StandardCharsets.UTF_8).trim();
            Log.i(TAG, "BLE command=" + command);

            RemoteAccessibilityService remote = RemoteAccessibilityService.getInstance();
            boolean handled = remote != null && remote.handleCommand(command);

            if (responseNeeded && gattServer != null) {
                gattServer.sendResponse(
                        device,
                        requestId,
                        handled ? BluetoothGatt.GATT_SUCCESS : BluetoothGatt.GATT_FAILURE,
                        offset,
                        null
                );
            }
        }
    };

    private final AdvertiseCallback advertiseCallback = new AdvertiseCallback() {
        @Override
        public void onStartSuccess(AdvertiseSettings settingsInEffect) {
            advertisingActive = true;
            setStatus(connectedClients > 0 ? "CONNECTED" : "ADVERTISING");
            Log.i(TAG, "BLE advertising started");
        }

        @Override
        public void onStartFailure(int errorCode) {
            if (errorCode == AdvertiseCallback.ADVERTISE_FAILED_ALREADY_STARTED) {
                advertisingActive = true;
                setStatus(connectedClients > 0 ? "CONNECTED" : "ADVERTISING");
                Log.w(TAG, "Advertising already started; treating as healthy");
                return;
            }

            advertisingActive = false;
            setStatus("ADVERTISE_ERROR_" + errorCode);
            Log.e(TAG, "BLE advertising failed error=" + errorCode);
            scheduleFullRecovery("advertise-" + errorCode, 1200);
        }
    };

    private final BroadcastReceiver adapterReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null || !BluetoothAdapter.ACTION_STATE_CHANGED.equals(intent.getAction())) return;
            int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR);
            Log.i(TAG, "Bluetooth adapter state=" + state);

            if (state == BluetoothAdapter.STATE_OFF || state == BluetoothAdapter.STATE_TURNING_OFF) {
                recoveryGeneration++;
                stopBleStack();
                setStatus("BLUETOOTH_OFF");
            } else if (state == BluetoothAdapter.STATE_ON) {
                handler.postDelayed(() -> startBleStack("adapter-on"), 700);
            }
        }
    };

    private final Runnable watchdog = new Runnable() {
        @Override
        public void run() {
            try { ensureHealthy("watchdog"); }
            catch (Throwable t) { Log.e(TAG, "watchdog exception", t); }
            handler.postDelayed(this, 7000);
        }
    };

    private void setStatus(String newStatus) {
        status = newStatus;
        Log.i(TAG, "STATUS=" + newStatus);
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(NOTIFICATION_ID, notification("BLE: " + newStatus));
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager != null) {
                manager.createNotificationChannel(new NotificationChannel(
                        CHANNEL,
                        "B1 Bluetooth Remote",
                        NotificationManager.IMPORTANCE_LOW
                ));
            }
        }
    }

    private Notification notification(String text) {
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);

        return builder
                .setContentTitle("B1 Remote Receiver")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
                .setOngoing(true)
                .build();
    }
}
