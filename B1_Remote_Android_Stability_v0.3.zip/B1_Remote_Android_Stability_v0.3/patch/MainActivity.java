package com.fks.b1remote;
import android.app.Activity;import android.content.Intent;import android.os.Build;import android.os.Bundle;import android.provider.Settings;import android.view.Gravity;import android.widget.Button;import android.widget.LinearLayout;import android.widget.TextView;
public class MainActivity extends Activity {
 private TextView controlStatus,bleStatus;
 public void onCreate(Bundle b){super.onCreate(b);LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(36,24,36,24);r.setGravity(Gravity.CENTER_HORIZONTAL);
 TextView t=new TextView(this);t.setText("B1 Remote Receiver — Stability v0.3");t.setTextSize(24);t.setGravity(Gravity.CENTER);r.addView(t,wide());
 controlStatus=new TextView(this);controlStatus.setTextSize(17);controlStatus.setGravity(Gravity.CENTER);r.addView(controlStatus,wide());bleStatus=new TextView(this);bleStatus.setTextSize(16);bleStatus.setGravity(Gravity.CENTER);r.addView(bleStatus,wide());
 Button a=button("OPEN ACCESSIBILITY SETTINGS");a.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));r.addView(a,wide());
 Button s=button("START / RESTART BLUETOOTH RECEIVER");s.setOnClickListener(v->{startBle();updateStatus();});r.addView(s,wide());
 LinearLayout x=row();x.addView(buttonFor("HOME","HOME"));x.addView(buttonFor("BACK","BACK"));r.addView(x,wide());
 x=row();x.addView(buttonFor("UP","UP"));x.addView(buttonFor("OK","OK"));x.addView(buttonFor("DOWN","DOWN"));r.addView(x,wide());
 x=row();x.addView(buttonFor("LEFT","LEFT"));x.addView(buttonFor("RIGHT","RIGHT"));r.addView(x,wide());
 x=row();x.addView(buttonFor("VOL-","VOL_DOWN"));x.addView(buttonFor("PLAY/PAUSE","PLAY_PAUSE"));x.addView(buttonFor("VOL+","VOL_UP"));r.addView(x,wide());
 TextView u=new TextView(this);u.setText("\nBLE service:\n"+BleRemoteService.SERVICE_UUID_STRING+"\n\nCommand characteristic:\n"+BleRemoteService.COMMAND_UUID_STRING+"\n\nWrite UTF-8: HOME, BACK, UP, DOWN, LEFT, RIGHT, OK, VOL_UP, VOL_DOWN, PLAY_PAUSE");u.setTextSize(13);u.setGravity(Gravity.CENTER);r.addView(u,wide());setContentView(r);startBle();}
 private void startBle(){Intent i=new Intent(this,BleRemoteService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);}protected void onResume(){super.onResume();updateStatus();}
 private void updateStatus(){controlStatus.setText(RemoteAccessibilityService.getInstance()!=null?"CONTROL SERVICE: READY":"CONTROL SERVICE: NOT READY");bleStatus.setText("BLE RECEIVER: "+BleRemoteService.getPublicStatus());}
 private Button buttonFor(String l,String c){Button b=button(l);b.setOnClickListener(v->{RemoteAccessibilityService s=RemoteAccessibilityService.getInstance();if(s!=null)s.handleCommand(c);updateStatus();});return b;}private Button button(String l){Button b=new Button(this);b.setText(l);b.setTextSize(15);b.setFocusable(true);return b;}private LinearLayout row(){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);r.setGravity(Gravity.CENTER);return r;}private LinearLayout.LayoutParams wide(){return new LinearLayout.LayoutParams(-1,-2);} }
