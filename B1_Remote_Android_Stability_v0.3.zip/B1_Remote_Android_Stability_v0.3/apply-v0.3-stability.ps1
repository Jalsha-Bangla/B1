﻿param(
    [string]$Project = "$env:USERPROFILE\Desktop\B1_Remote_Receiver_BLE_POC_v0.2\B1_Remote_Receiver_BLE_POC_v0.2",
    [string]$B1IP = "192.168.68.107"
)

$ErrorActionPreference = "Stop"
$adb = "$env:LOCALAPPDATA\Android\Sdk\platform-tools\adb.exe"
$B1 = "${B1IP}:5555"

$JavaDir = Join-Path $Project "app\src\main\java\com\fks\b1remote"
$ManifestDst = Join-Path $Project "app\src\main\AndroidManifest.xml"
$BleDst = Join-Path $JavaDir "BleRemoteService.java"
$BootDst = Join-Path $JavaDir "BootReceiver.java"
$MainDst = Join-Path $JavaDir "MainActivity.java"
$Builder = Join-Path $Project "build-install-test-v0.2.ps1"
$KeyStore = Join-Path $Project "b1_poc_debug.keystore"

function Require([string]$p) { if (-not (Test-Path $p)) { throw "Missing required path: $p" } }

Write-Host "`n=== B1 REMOTE v0.3 CONNECTION STABILITY UPDATE ===" -ForegroundColor Cyan
foreach ($p in @($adb,$Project,$JavaDir,$ManifestDst,$Builder,$KeyStore)) { Require $p }

Write-Host "`n[1/7] Connecting to B1..." -ForegroundColor Yellow
& $adb start-server | Out-Null
& $adb connect $B1 | Out-Host
& $adb -s $B1 get-state | Out-Host

Write-Host "`n[2/7] Backing up current proven source..." -ForegroundColor Yellow
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
foreach ($p in @($ManifestDst,$BleDst,$BootDst,$MainDst)) {
    if (Test-Path $p) { Copy-Item $p "$p.pre-v0.3_$stamp.bak" -Force }
}
Write-Host "Backup stamp: $stamp"

Write-Host "`n[3/7] Applying v0.3 recovery logic..." -ForegroundColor Yellow
Copy-Item (Join-Path $PSScriptRoot "patch\AndroidManifest.xml") $ManifestDst -Force
Copy-Item (Join-Path $PSScriptRoot "patch\BleRemoteService.java") $BleDst -Force
Copy-Item (Join-Path $PSScriptRoot "patch\BootReceiver.java") $BootDst -Force
Copy-Item (Join-Path $PSScriptRoot "patch\MainActivity.java") $MainDst -Force
Remove-Item (Join-Path $Project "build") -Recurse -Force -ErrorAction SilentlyContinue

Write-Host "`n[4/7] Building + updating with EXISTING signing key..." -ForegroundColor Yellow
Push-Location $Project
try {
    Set-ExecutionPolicy -Scope Process Bypass -Force
    & $Builder -B1 $B1
} finally { Pop-Location }

$Built = Join-Path $Project "build\B1_Remote_Receiver_BLE_POC_v0.2.apk"
Require $Built
$Final = Join-Path $Project "build\B1_Remote_Receiver_Stability_v0.3.apk"
Copy-Item $Built $Final -Force
Write-Host "[PASS] Updated APK: $Final" -ForegroundColor Green

Write-Host "`n[5/7] Ensuring receiver is running..." -ForegroundColor Yellow
& $adb -s $B1 shell am start-foreground-service -n com.fks.b1remote/.BleRemoteService | Out-Host
Start-Sleep 4

Write-Host "`n[6/7] Verifying v0.3 service health..." -ForegroundColor Yellow
$svc = & $adb -s $B1 shell dumpsys activity services com.fks.b1remote
$notif = & $adb -s $B1 shell dumpsys notification --noredact
$logs = & $adb -s $B1 logcat -d -s B1RemoteBLE:I "*:S"
$svc | Select-String -Pattern "BleRemoteService|RemoteAccessibilityService" -Context 0,4 | Select-Object -First 50
$notif | Select-String -Pattern "B1 Remote Receiver|BLE:" -Context 0,2 | Select-Object -First 20
$logs | Select-Object -Last 100

Write-Host "`n[7/7] Fast recovery pre-test..." -ForegroundColor Yellow
Write-Host "Receiver v0.3 installed. Do the iPhone reconnect stress-test after iOS v0.3 is installed." -ForegroundColor Cyan
Write-Host "PASS target: 10-20 deliberate disconnect/reconnect cycles with no manual B1 receiver restart." -ForegroundColor Cyan

Write-Host "`n=== B1 REMOTE v0.3 ANDROID UPDATE COMPLETE ===" -ForegroundColor Green
