# B1 Remote Android Receiver v0.3 — Connection Stability

Patches the already-proven v0.2/v0.2.3 receiver **in place** so the existing signing keystore is reused.

## Hardening
- force-restarts BLE advertising after every GATT disconnect
- 7-second BLE health watchdog
- rebuilds GATT server after stack/advertising errors
- dynamically recovers after Bluetooth OFF → ON
- preserves BootReceiver auto-start
- preserves HiRemote / vendor remote components untouched
- preserves the same BLE service/command UUIDs

## Important
Do not generate a new Android signing key. The script requires the existing `b1_poc_debug.keystore`, ensuring `adb install -r` is a valid update.
