import SwiftUI

@main
struct B1RemoteApp: App {
    @StateObject private var remote = BluetoothRemoteManager()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(remote)
        }
    }
}
