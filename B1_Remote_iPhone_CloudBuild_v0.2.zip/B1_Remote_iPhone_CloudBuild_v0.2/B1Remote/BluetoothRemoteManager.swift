import Foundation
import CoreBluetooth
import Combine

final class BluetoothRemoteManager: NSObject, ObservableObject {
    static let serviceUUID = CBUUID(string: "7B3E1001-2F9A-4E2A-9A6B-1C6C0F9B1001")
    static let commandUUID = CBUUID(string: "7B3E1002-2F9A-4E2A-9A6B-1C6C0F9B1001")

    @Published var statusText = "Starting Bluetooth…"
    @Published var isReady = false

    private var central: CBCentralManager!
    private var peripheral: CBPeripheral?
    private var commandCharacteristic: CBCharacteristic?
    private var reconnectWorkItem: DispatchWorkItem?

    override init() {
        super.init()
        central = CBCentralManager(delegate: self, queue: .main)
    }

    func reconnect() {
        reconnectWorkItem?.cancel()
        isReady = false
        commandCharacteristic = nil

        if let peripheral, peripheral.state != .connected {
            statusText = "Connecting…"
            central.connect(peripheral, options: nil)
        } else if central.state == .poweredOn {
            startScanning()
        }
    }

    func send(_ command: String) {
        guard
            let peripheral,
            peripheral.state == .connected,
            let characteristic = commandCharacteristic,
            let data = command.data(using: .utf8)
        else {
            statusText = "Not connected"
            isReady = false
            reconnect()
            return
        }

        let type: CBCharacteristicWriteType
        if characteristic.properties.contains(.write) {
            type = .withResponse
        } else if characteristic.properties.contains(.writeWithoutResponse) {
            type = .withoutResponse
        } else {
            statusText = "Command channel is not writable"
            return
        }

        peripheral.writeValue(data, for: characteristic, type: type)
    }

    private func startScanning() {
        guard central.state == .poweredOn else { return }

        statusText = "Searching for B1…"
        isReady = false
        commandCharacteristic = nil

        central.stopScan()
        central.scanForPeripherals(
            withServices: [Self.serviceUUID],
            options: [CBCentralManagerScanOptionAllowDuplicatesKey: false]
        )
    }

    private func scheduleReconnect() {
        reconnectWorkItem?.cancel()

        let item = DispatchWorkItem { [weak self] in
            guard let self else { return }
            if self.central.state == .poweredOn {
                self.reconnect()
            }
        }

        reconnectWorkItem = item
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0, execute: item)
    }
}

extension BluetoothRemoteManager: CBCentralManagerDelegate {
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
        case .poweredOn:
            startScanning()
        case .poweredOff:
            statusText = "Bluetooth is Off"
            isReady = false
        case .unauthorized:
            statusText = "Bluetooth permission needed"
            isReady = false
        case .unsupported:
            statusText = "Bluetooth LE unsupported"
            isReady = false
        case .resetting:
            statusText = "Bluetooth resetting…"
            isReady = false
        case .unknown:
            statusText = "Bluetooth state unknown"
            isReady = false
        @unknown default:
            statusText = "Bluetooth unavailable"
            isReady = false
        }
    }

    func centralManager(
        _ central: CBCentralManager,
        didDiscover peripheral: CBPeripheral,
        advertisementData: [String : Any],
        rssi RSSI: NSNumber
    ) {
        central.stopScan()
        self.peripheral = peripheral
        peripheral.delegate = self
        statusText = "Connecting to B1…"
        central.connect(peripheral, options: nil)
    }

    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        statusText = "Discovering remote service…"
        peripheral.discoverServices([Self.serviceUUID])
    }

    func centralManager(
        _ central: CBCentralManager,
        didFailToConnect peripheral: CBPeripheral,
        error: Error?
    ) {
        statusText = "Connection failed — retrying…"
        isReady = false
        scheduleReconnect()
    }

    func centralManager(
        _ central: CBCentralManager,
        didDisconnectPeripheral peripheral: CBPeripheral,
        error: Error?
    ) {
        statusText = "Disconnected — reconnecting…"
        isReady = false
        commandCharacteristic = nil
        scheduleReconnect()
    }
}

extension BluetoothRemoteManager: CBPeripheralDelegate {
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        if let error {
            statusText = "Service discovery failed: \(error.localizedDescription)"
            scheduleReconnect()
            return
        }

        guard let service = peripheral.services?.first(where: { $0.uuid == Self.serviceUUID }) else {
            statusText = "B1 service not found"
            scheduleReconnect()
            return
        }

        peripheral.discoverCharacteristics([Self.commandUUID], for: service)
    }

    func peripheral(
        _ peripheral: CBPeripheral,
        didDiscoverCharacteristicsFor service: CBService,
        error: Error?
    ) {
        if let error {
            statusText = "Command discovery failed: \(error.localizedDescription)"
            scheduleReconnect()
            return
        }

        guard let characteristic = service.characteristics?.first(where: { $0.uuid == Self.commandUUID }) else {
            statusText = "B1 command channel not found"
            scheduleReconnect()
            return
        }

        commandCharacteristic = characteristic
        isReady = true
        statusText = "B1 Connected"
    }

    func peripheral(
        _ peripheral: CBPeripheral,
        didWriteValueFor characteristic: CBCharacteristic,
        error: Error?
    ) {
        if let error {
            statusText = "Command failed: \(error.localizedDescription)"
        } else if isReady {
            statusText = "B1 Connected"
        }
    }
}
