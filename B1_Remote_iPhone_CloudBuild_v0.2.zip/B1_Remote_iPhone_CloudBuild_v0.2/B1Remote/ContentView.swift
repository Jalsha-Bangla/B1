import SwiftUI
import UIKit

struct ContentView: View {
    @EnvironmentObject private var remote: BluetoothRemoteManager
    private let feedback = UIImpactFeedbackGenerator(style: .light)

    var body: some View {
        ZStack {
            Color(.systemBackground).ignoresSafeArea()

            ScrollView {
                VStack(spacing: 22) {
                    header
                    statusCard
                    navigationPad
                    transportRow
                    volumeRow
                }
                .padding(.horizontal, 22)
                .padding(.vertical, 18)
            }
        }
    }

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 3) {
                Text("B1 Remote")
                    .font(.system(size: 30, weight: .bold, design: .rounded))
                Text("Bluetooth • Wi‑Fi not required")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Button {
                remote.reconnect()
            } label: {
                Image(systemName: "arrow.clockwise")
                    .font(.title3.weight(.semibold))
                    .frame(width: 44, height: 44)
                    .background(.thinMaterial, in: Circle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Reconnect")
        }
    }

    private var statusCard: some View {
        HStack(spacing: 12) {
            Circle()
                .frame(width: 10, height: 10)
                .foregroundStyle(remote.isReady ? .green : .orange)

            Text(remote.statusText)
                .font(.headline)

            Spacer()
        }
        .padding(16)
        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private var navigationPad: some View {
        ZStack {
            Circle()
                .fill(.thinMaterial)
                .frame(width: 290, height: 290)

            VStack(spacing: 34) {
                remoteButton(symbol: "chevron.up", command: "UP", size: 64)

                HStack(spacing: 34) {
                    remoteButton(symbol: "chevron.left", command: "LEFT", size: 64)

                    Button {
                        send("OK")
                    } label: {
                        Text("OK")
                            .font(.system(size: 24, weight: .bold, design: .rounded))
                            .frame(width: 82, height: 82)
                            .background(.primary.opacity(0.10), in: Circle())
                    }
                    .buttonStyle(.plain)
                    .disabled(!remote.isReady)

                    remoteButton(symbol: "chevron.right", command: "RIGHT", size: 64)
                }

                remoteButton(symbol: "chevron.down", command: "DOWN", size: 64)
            }
        }
        .opacity(remote.isReady ? 1.0 : 0.55)
    }

    private var transportRow: some View {
        HStack(spacing: 14) {
            labeledButton(title: "Back", symbol: "arrow.uturn.backward", command: "BACK")
            labeledButton(title: "Home", symbol: "house.fill", command: "HOME")
            labeledButton(title: "Play", symbol: "playpause.fill", command: "PLAY_PAUSE")
        }
    }

    private var volumeRow: some View {
        HStack(spacing: 14) {
            labeledButton(title: "Volume −", symbol: "speaker.minus.fill", command: "VOL_DOWN")
            labeledButton(title: "Volume +", symbol: "speaker.plus.fill", command: "VOL_UP")
        }
    }

    private func remoteButton(symbol: String, command: String, size: CGFloat) -> some View {
        Button {
            send(command)
        } label: {
            Image(systemName: symbol)
                .font(.system(size: 25, weight: .bold))
                .frame(width: size, height: size)
                .background(.primary.opacity(0.08), in: Circle())
        }
        .buttonStyle(.plain)
        .disabled(!remote.isReady)
        .accessibilityLabel(command)
    }

    private func labeledButton(title: String, symbol: String, command: String) -> some View {
        Button {
            send(command)
        } label: {
            VStack(spacing: 7) {
                Image(systemName: symbol)
                    .font(.title2)
                Text(title)
                    .font(.caption.weight(.semibold))
            }
            .frame(maxWidth: .infinity)
            .frame(height: 74)
            .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        }
        .buttonStyle(.plain)
        .disabled(!remote.isReady)
        .opacity(remote.isReady ? 1.0 : 0.55)
    }

    private func send(_ command: String) {
        feedback.prepare()
        feedback.impactOccurred()
        remote.send(command)
    }
}
