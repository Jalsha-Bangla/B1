# B1 Remote iPhone — Cloud Build v0.2

This package avoids the need for a new Mac or a local Xcode installation.

## Architecture already proven on the B1
iPhone -> Bluetooth LE -> B1 -> Accessibility Service -> Android TV

BLE service:
`7B3E1001-2F9A-4E2A-9A6B-1C6C0F9B1001`

Command characteristic:
`7B3E1002-2F9A-4E2A-9A6B-1C6C0F9B1001`

Commands:
`HOME`
`BACK`
`UP`
`DOWN`
`LEFT`
`RIGHT`
`OK`
`VOL_UP`
`VOL_DOWN`
`PLAY_PAUSE`

## Build without a Mac

1. Create a new private GitHub repository.
2. Upload the **contents of this folder** to the repository root.
   The `.github/workflows/build-ipa.yml` file must remain in that exact location.
3. Open the repository's **Actions** tab.
4. Select **Build B1 Remote IPA**.
5. Choose **Run workflow**.
6. When the job is green, open it and download artifact:
   `B1-Remote-iPhone-v0.2-IPA`
7. Extract the artifact ZIP. Inside is:
   `B1_Remote_iPhone_v0.2_unsigned.ipa`

The IPA is intentionally not Apple-signed in the cloud. AltServer/AltStore signs it for your own iPhone during sideloading.

## Windows sideload

Official AltStore Windows guidance requires Apple-distributed iTunes and iCloud, not the Microsoft Store versions.

After AltServer is installed and your iPhone trusts the PC, either:
- Install AltStore, then sideload the IPA from AltStore; or
- Hold **Shift** while clicking AltServer's system-tray icon and choose **Sideload .ipa...** for direct sideloading.

For iOS 16 and newer, Developer Mode must be enabled on the iPhone.

With a free Apple ID, sideloaded apps need to be refreshed/reinstalled about every 7 days.

## Security
The app contains no Wi-Fi/network control code and no credentials.
It scans only for the B1 BLE service UUID and writes the tested UTF-8 remote commands to the tested command characteristic.
